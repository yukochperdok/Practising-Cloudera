package com.mbit.creacionUDF;

import java.sql.Timestamp;

import junit.framework.TestCase;

import org.apache.hadoop.hive.serde2.io.DateWritable;
import org.apache.hadoop.hive.serde2.io.TimestampWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.junit.Test;

public class TestYear extends TestCase {

  @Test
  public void testUDFYearTimestamp() throws Exception {
    // Running example
    // Friday 30th August 1985 02:47:02 AM
    final TimestampWritable t =
        new TimestampWritable(new Timestamp(494218022082L));

    Year g;
    g = new Year();
    IntWritable i1 = g.evaluate(t);
    assertEquals(1985, i1.get());

  }

  @Test
  public void testUDFYearDate() throws Exception {
    // Running example
    // Dia Actual
    final java.sql.Date date = new java.sql.Date(System.currentTimeMillis());
    final DateWritable d = new DateWritable(date);


    Year g;
    g = new Year();
    IntWritable i1 = g.evaluate(d);
    assertEquals(2016, i1.get());

  }

  @Test
  public void testUDFYearText() throws Exception {
    // Running example
    // 2005-07-30
    final Text t = new Text("2005-07-30");

    Year g;
    g = new Year();
    IntWritable i1 = g.evaluate(t);
    assertEquals(2005, i1.get());

  }

}